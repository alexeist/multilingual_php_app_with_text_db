<?php
$links = array(
       'home'     => "#",
	   'feauteres' => "#",
	   'read_me'  => "ReadMe.php"
 );
 $area_expanded = array_key_exists('a_e', $_REQUEST)?true : false;
?>	 

		 	 			
			<nav class="nav navbar navbar-default" >           				
				<div class = "nav container-fluid">            		     					   					  
					<div class="navbar-header">      
						<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse-mod" aria-expanded="<?php echo($area_expanded)?>">        
							<span class="sr-only">Toggle navigation
							</span>        
							<span class="icon-bar">
							</span>        
							<span class="icon-bar">
							</span>        
							<span class="icon-bar">
							</span>      
						</button>      
						<a class ="navbar-brand " href="#">
							<?php echo($labels[1]) ?></a>      
					</div>  					    	   
					<div class="collapse navbar-collapse" id="collapse-mod">				    					              					 					    
						<ul class="nav navbar-nav">  					    					                   		            						
							<li>  						
							<a href="<?php echo($links['home'])?>?lng=<?php echo($lng)?>" title="
								<?php echo($labels[6]) ?>" > 							
								<?php echo($labels[3]) ?></a>						
							</li>		            						
							<li>  						
							<a href="<?php echo($links['feauteres'])?>?lng=<?php echo($lng)?>" title="
								<?php echo($labels[4]) ?>" > 							
								<?php echo($labels[4]) ?></a>						
							</li>		            						
							<li>  						
							<a href="readme/ReadMe_<?php echo($lng)?>.txt?lng=<?php echo($lng)?>" title="
								<?php echo($labels[6]) ?>" > 							
								<?php echo($labels[11]) ?></a>						
							</li>               					
							<li>			 				              					
												
							</li>					
							<li>		            		                  					
							<!-- insert lang_panel  -->  			                					
							<?php echo ($lang_panel); ?>     					
							</li>						
						</ul>  				
					</div>		                                      				
				</div>  			 			
			</nav>		 			
			    		
