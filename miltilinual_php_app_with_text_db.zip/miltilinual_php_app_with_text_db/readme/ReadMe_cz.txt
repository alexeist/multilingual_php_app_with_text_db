Čti mi Česky
Tento soubor vysvětluje, jak používat balíček jazykových panelů...
1 Požadavek:
  1.1 HTTP server jako Appache
   1.2 Server PHP verze 5.xx a novější
2 Instalace
  2.1 Nainstalujte tento skript na své stránky, jako je tomu v tomto příkladu - 'index.php'
  2.2 vytvořte výchozí seznam jazyků v souboru 'languages/en.txt', kam umístěte každý štítek, který potřebujete přeložit do jiného jazyka
  2.3 upravte pole $langs a umístěte tam všechny dostupné jazyky, proměnná se najde v souboru 'lang_panel.php'.
  2.4 upravte pole $lang_title a přidejte potřebné názvy jazyků, proměnná se nachází v souboru 'lang_panel.php'.
3 První spuštění programu
  3.1 Spusťte program.
   3.1.1 Zobrazí se pouze jeden příznak aktuálního jazyka.
   3.1.2 Celá galerie příznaků jazyků je skrytá, dokud uživatel neklikne na příznak aktuálního jazyka.
   3.2 Klikněte na vlajku aktuálního jazyka, zobrazí se příznaky plné avalabel jazyka.
   3.3 Kliknutím na příznak vybraného jazyka se změní globální proměnná $lng na hodnotu nového jazyka. A stránka se znovu načte se skrytou galerií glagů a zobrazí pouze vlajku nového jazyka.
   3.4 Pokud soubor s názvem '&lt;kód jazyka&gt;.txt' neexistuje, skript automaticky vytvoří kopii výchozího jazykového souboru s novým názvem jazyka a zobrazí zprávu o něm.
4 klikněte na každý příznak jazyka
přidal jsi. Ve výsledku skript
  automaticky
  vytvoří úplný komplet souborů pro překlad . Každý nový soubor bude mít stejný text jako soubor výchozího jazyků (obvykle en.txt).
  4.1 Poté, co budete mít všechny soubory pro překlad štítků z výchozího jazyka, můžete postupně zkopírovat text z příslušného souboru '&lt;kód jazyka&gt;.txt' a odeslat jej překladateli.
4.2 Vložte přeložený text do nového jazykového souboru
STROHO DO STEJNÝCH ČÍSEL ŘAD
5 Co dělat, když...
  5.1 Co dělat, pokud se ve vybraném novém jazyce štítky zobrazují nesprávně?
    Odpovědět:
    5.1.1 Zkontrolujte počty přeložených slov. Každé přeložené slovo musí být umístěno silně ve stejných řádcích jako ve výchozím jazykovém souboru
  5.2 Co dělat, pokud jsou štítky všech jazyků umístěny nesprávně?
    Odpovědět:
    5.1.2 Zkontrolujte počty řádků ve výchozím jazykovém souboru (obvykle 'jazyk/en.txt') a uveďte je do souladu s php skriptem, který jej používá.
    5.1.3 Poté, co výchozí jazyk zobrazí správné štítky, upravte soubory všech ostatních jazyků tak, aby byly v souladu se souborem výchozího jazyka;
        DŮLEŽITÁ POZNÁMKA: Přeložený text musí být umístěn pevně ve STEJNÝCH ŘÁDCÍCH jako ve výchozím jazykovém souboru.
Pro ovládání je tedy nutné použít editor s čísly řetězců.