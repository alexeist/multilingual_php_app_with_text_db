<?php
//------------- connect the libraries

?>


<!DOCTYPE HTML">
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="generator" content="PSPad editor, www.pspad.com">
    <title><?php print($labels[1])?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">

    <link rel="stylesheet" href="assets/style/style.css" type="text/css" media="screen" />
  </head>
  <body>  
<?php
	include_once("lang_panel.php");
	check_available_lang(PATH_TO_LANGUAGES . DIRECTORY_SEPARATOR . $lng . DB_FILES_EXTENSION);
	$labels = file(PATH_TO_LANGUAGES . DIRECTORY_SEPARATOR . $lng . DB_FILES_EXTENSION);
	array_unshift($labels, "[". $lang_title[$lng] . "]");
	include_once("menu_up.php");
?>
<div class="container">
<div class="row">
<!-- TO DO -->
<div class="center">
<h2><?php echo($labels[8])?></h4>
<p><?php echo($labels[9])?></p>
<p><?php echo($labels[10])?></p>
 </div>

</div>
<!-- TO DO -->
</div>
    <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@3.4.1/dist/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
</body>
</html>
 



  

